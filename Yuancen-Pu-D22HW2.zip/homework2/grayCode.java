public class grayCode {
    public grayCode(){

    }
}
